<?php include "./assets/header.php"; ?>

<div class="container-fluid">
    <h1>PLC Connection Status</h1>
    <div id="statusBox">🔄 Checking...</div>
</div>

<?php include "./assets/footer.php"; ?>