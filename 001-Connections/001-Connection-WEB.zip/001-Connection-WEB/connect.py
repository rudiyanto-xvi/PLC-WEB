import snap7

client = snap7.client.Client()
try:
    client.connect('192.168.0.101', 0, 1)
    print("Connected:", client.get_connected())
    client.disconnect()
except Exception as e:
    print("Failed to connect:", str(e))
