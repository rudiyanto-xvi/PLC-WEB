from flask import Flask, jsonify
from flask_cors import CORS
import snap7

app = Flask(__name__)
CORS(app)  # Izinkan akses dari domain lain

PLC_IP = '192.168.0.101'
RACK = 0
SLOT = 1

@app.route('/status')
def plc_status():
    try:
        client = snap7.client.Client()
        client.connect(PLC_IP, RACK, SLOT)
        status = "connected" if client.get_connected() else "disconnected"
        client.disconnect()
    except:
        status = "disconnected"
    return jsonify({"status": status})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
