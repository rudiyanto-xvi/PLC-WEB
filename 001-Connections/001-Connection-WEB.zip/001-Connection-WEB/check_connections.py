import snap7

# Inisialisasi client
client = snap7.client.Client()

# IP address PLC, dan konfigurasi Rack dan Slot
PLC_IP = '192.168.0.101'  # Ganti sesuai IP PLC-mu
RACK = 0
SLOT = 1

try:
    # Coba koneksi ke PLC
    client.connect(PLC_IP, RACK, SLOT)
    
    if client.get_connected():
        print(f"Berhasil terhubung ke PLC di {PLC_IP}")
    else:
        print("Gagal terhubung ke PLC.")

except Exception as e:
    print(f"Terjadi kesalahan saat mencoba koneksi: {e}")

finally:
    # Putuskan koneksi jika sudah tidak diperlukan
    client.disconnect()
    print("Koneksi diputuskan.")