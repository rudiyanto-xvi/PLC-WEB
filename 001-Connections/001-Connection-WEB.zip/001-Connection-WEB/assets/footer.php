</div>
<!-- End of Page Wrapper -->
</div>
<!-- End of Main Content -->

<script>
    const statusBox = document.getElementById("statusBox");

    function checkStatus() {
        fetch("http://localhost:5000/status") // <--- endpoint Flask
            .then(res => res.json())
            .then(data => {
                statusBox.innerHTML = data.status === "connected" ?
                    "✅ <span style='color:green'>Connected</span>" :
                    "❌ <span style='color:red'>Disconnected</span>";
            }).catch(() => {
                statusBox.innerHTML = "❌ <span style='color:red'>Disconnected</span>";
            });
    }

    checkStatus();
    setInterval(checkStatus, 1000); // setiap 1 detik
</script>

<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/chart-area-demo.js"></script>
<script src="js/demo/chart-pie-demo.js"></script>
</body>

</html>