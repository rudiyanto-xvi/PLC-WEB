<?php include "./assets/header.php"; ?>

<div class="container-fluid">
    <!-- Connecion to PLC -->
    <h5>PLC Connection Status</h5>
    <div id="statusBox">🔄 Checking...</div>


    <div class="mt-4 mb-4">
        <h5>Push Button</h5>
        <button class="btn btn-success" onclick="sendCommand('DB_START', true)">START</button>
        <button class="btn btn-danger" onclick="sendCommand('DB_STOP', true)">STOP</button>
    </div>
</div>

<?php include "./assets/footer.php"; ?>