import snap7
from snap7.util import set_bool

PLC_IP = "192.168.0.101"
client = snap7.client.Client()
client.connect(PLC_IP, 0, 1)

buffer = client.db_read(1, 0, 1)
set_bool(buffer, 0, 0, True)  # Set DB1.DBX0.0 = TRUE
client.db_write(1, 0, buffer)

client.disconnect()
print("Write success")
