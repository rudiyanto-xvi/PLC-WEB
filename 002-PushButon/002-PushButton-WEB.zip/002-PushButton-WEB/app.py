from flask import Flask, jsonify, request
from flask_cors import CORS
import snap7
from snap7.util import get_bool, get_dint, set_bool

app = Flask(__name__)
CORS(app)

PLC_IP = '192.168.0.101'
RACK = 0
SLOT = 1
DB_MAIN = 1 

@app.route('/status')
def plc_status():
    try:
        client = snap7.client.Client()
        client.connect(PLC_IP, RACK, SLOT)
        status = "connected" if client.get_connected() else "disconnected"
        client.disconnect()
    except:
        status = "disconnected"
    return jsonify({"status": status})

@app.route('/write-bit', methods=['POST'])
def write_bit():
    data = request.json
    bit_name = data.get("name")
    value = data.get("value")

    bit_map = {
        "DB_START": (0, 0),
        "DB_STOP": (0, 1)
    }

    if bit_name not in bit_map:
        return jsonify({"status": "error", "message": "Invalid bit name"}), 400

    byte_index, bit_index = bit_map[bit_name]

    try:
        client = snap7.client.Client()
        client.connect(PLC_IP, RACK, SLOT)

        if not client.get_connected():
            return jsonify({"status": "error", "message": "PLC not connected"}), 500

        buffer = client.db_read(DB_MAIN, byte_index, 1)
        set_bool(buffer, byte_index, bit_index, value)
        client.db_write(DB_MAIN, byte_index, buffer)

        client.disconnect()
        return jsonify({"status": "updated", "bit": bit_name, "value": value})

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
